"""Package marker for the Photo Service."""
