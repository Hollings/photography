"""Utility helpers (hashing, EXIF, variants, S3 storage)."""
